from setuptools import setup

setup(name='dsnd_nes_probability',
      version='0.1',
      description='Gaussian & bionmial distributions',
      packages=['dsnd_nes_probability'],
      author = 'Nesreen Sada',
      author_email ='nesreensada@gmail.com',
      zip_safe=False)
